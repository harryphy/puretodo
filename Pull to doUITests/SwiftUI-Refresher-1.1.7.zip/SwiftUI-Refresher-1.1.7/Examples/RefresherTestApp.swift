//
//  RefresherTestApp.swift
//  Shared
//
//  Created by Brian Floersch on 4/17/22.
//

import SwiftUI

@main
struct RefresherTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
